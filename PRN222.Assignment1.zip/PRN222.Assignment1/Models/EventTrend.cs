﻿namespace PRN222.Assignment1.Models
{
    public class EventTrend
    {
        public int EventId { get; set; }
        public string Title { get; set; }
        public int TotalAttendees { get; set; }
    }
}
